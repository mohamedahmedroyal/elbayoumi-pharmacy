import { all, transaction } from '../database';
import { QTY_SCALE } from '../../lib/qty';

export type InvoiceKind = 'sale' | 'purchase';
export interface InvoiceItem { id: number; name: string; code: string; unit: string; balance: number; }
export interface InvoiceLine { item_id: number; name: string; unit: string; qty: number; price: number; cost?: number; }
export interface InvoiceSummary { id: number; invoice_no: string; party_name: string | null; total: number; created_at: string; }
export async function invoiceItems(): Promise<InvoiceItem[]> {
  return all<InvoiceItem>(`SELECT i.id,i.name,i.code,i.unit,COALESCE(SUM(b.qty_remaining),0) balance
    FROM items i LEFT JOIN batches b ON b.item_id=i.id WHERE i.is_active=1 GROUP BY i.id ORDER BY i.name`);
}
export async function saveInvoice(kind: InvoiceKind, lines: InvoiceLine[], details: { party: string; batchNo: string; expiry: string; notes: string }): Promise<number> {
  if (!lines.length) throw new Error('أضف صنفاً واحداً على الأقل');
  if (kind === 'purchase' && (!details.batchNo.trim() || !details.expiry)) throw new Error('رقم التشغيلة وتاريخ الصلاحية مطلوبان');
  for (const l of lines) {
    if (!Number.isInteger(l.qty) || l.qty <= 0) throw new Error(`الكمية غير صحيحة للصنف ${l.name}`);
    if (!Number.isInteger(l.price) || l.price < 0) throw new Error(`السعر غير صحيح للصنف ${l.name}`);
    if (kind === 'purchase' && (!Number.isInteger(l.cost) || (l.cost ?? -1) < 0)) throw new Error(`التكلفة غير صحيحة للصنف ${l.name}`);
  }
  return transaction(async tx => {
    const total = lines.reduce((s,l) => s + Math.round(l.qty * (kind === 'purchase' ? (l.cost ?? 0) : l.price) / QTY_SCALE), 0);
    const count = await tx.all<{n:number}>(`SELECT COUNT(*) n FROM ${kind}_invoices`);
    const invoiceNo = `${kind === 'sale' ? 'SAL' : 'PUR'}-${String(count[0].n+1).padStart(6,'0')}`;
    const header = await tx.run(`INSERT INTO ${kind}_invoices(invoice_no,party_name,total,notes) VALUES (?,?,?,?)`, [invoiceNo, details.party.trim() || null,total,details.notes.trim() || null]);
    for (const l of lines) {
      if (kind === 'purchase') {
        await tx.run(`INSERT INTO purchase_invoice_lines(invoice_id,item_id,qty,unit_cost,unit_price) VALUES (?,?,?,?,?)`,[header.lastId,l.item_id,l.qty,l.cost ?? 0,l.price]);
        const batch = await tx.run(`INSERT INTO batches(item_id,batch_no,purchase_date,expiry_date,qty_in,qty_remaining,unit_price,unit_cost)
          VALUES (?,?,date('now','localtime'),?,?,?,?,?)`,[l.item_id,details.batchNo.trim(),details.expiry,l.qty,l.price,l.cost ?? 0]);
        await tx.run(`INSERT INTO stock_movements(item_id,batch_id,movement_type,qty,unit_cost,doc_type,doc_id) VALUES (?,?,?,?,?,'purchase',?)`,[l.item_id,batch.lastId,l.qty,l.cost ?? 0,header.lastId]);
      } else {
        const batches = await tx.all<{id:number;qty_remaining:number;unit_cost:number;expiry_date:string}>(`SELECT id,qty_remaining,unit_cost,expiry_date FROM batches WHERE item_id=? AND qty_remaining>0 AND expiry_date>=date('now','localtime') ORDER BY expiry_date,id`,[l.item_id]);
        const available = batches.reduce((s,b)=>s+b.qty_remaining,0);
        if (available < l.qty) throw new Error(`رصيد ${l.name} غير كافٍ. المتاح ${available / QTY_SCALE}`);
        let remaining=l.qty;
        for (const b of batches) {
          if (!remaining) break;
          const take=Math.min(remaining,b.qty_remaining);
          await tx.run('UPDATE batches SET qty_remaining=qty_remaining-?,qty_sold=qty_sold+? WHERE id=?',[take,take,b.id]);
          await tx.run(`INSERT INTO stock_movements(item_id,batch_id,movement_type,qty,unit_cost,doc_type,doc_id) VALUES (?,?, 'sale',?,?, 'sale',?)`,[l.item_id,b.id,-take,b.unit_cost,header.lastId]);
          remaining-=take;
        }
        await tx.run(`INSERT INTO sales_invoice_lines(invoice_id,item_id,qty,unit_price) VALUES (?,?,?,?)`,[header.lastId,l.item_id,l.qty,l.price]);
      }
    }
    await tx.run('INSERT INTO audit_log(entity,entity_id,action,details) VALUES (?,?,?,?)',['invoice',header.lastId,kind,JSON.stringify({invoiceNo,total})]);
    return header.lastId;
  });
}
export async function recentInvoices(kind: InvoiceKind): Promise<InvoiceSummary[]> {
  return all<InvoiceSummary>(`SELECT id,invoice_no,party_name,total,created_at FROM ${kind}_invoices ORDER BY id DESC LIMIT 30`);
}
