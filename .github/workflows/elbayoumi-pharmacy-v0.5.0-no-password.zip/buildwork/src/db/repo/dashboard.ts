import { all } from '../database';

export interface ExpiringBatch {
  id: number;
  item_name: string;
  batch_no: string;
  expiry_date: string;
  qty_remaining: number;
  days_left: number;
}

export interface DashboardData {
  itemCount: number;
  stockValue: number; // بالقرش
  lowStockCount: number;
  expiredCount: number;
  nearestBatches: ExpiringBatch[];
}

export async function loadDashboard(): Promise<DashboardData> {
  const [counts] = await all<{ n: number }>('SELECT COUNT(*) AS n FROM items WHERE is_active = 1');
  const [value] = await all<{ v: number }>('SELECT CAST(ROUND(COALESCE(SUM(qty_remaining * unit_cost),0) / 1000.0) AS INTEGER) AS v FROM batches');
  const [low] = await all<{ n: number }>(`
    SELECT COUNT(*) AS n FROM (
      SELECT i.id FROM items i LEFT JOIN batches b ON b.item_id = i.id
      WHERE i.is_active = 1 AND i.min_stock > 0
      GROUP BY i.id HAVING COALESCE(SUM(b.qty_remaining),0) <= i.min_stock
    )`);
  const [expired] = await all<{ n: number }>(
    "SELECT COUNT(*) AS n FROM batches WHERE qty_remaining > 0 AND expiry_date < date('now','localtime')",
  );
  const nearest = await all<ExpiringBatch>(`
    SELECT b.id, i.name AS item_name, b.batch_no, b.expiry_date, b.qty_remaining,
      CAST(julianday(b.expiry_date) - julianday(date('now','localtime')) AS INTEGER) AS days_left
    FROM batches b JOIN items i ON i.id = b.item_id
    WHERE b.qty_remaining > 0
    ORDER BY b.expiry_date ASC LIMIT 5`);

  return {
    itemCount: counts.n,
    stockValue: value.v,
    lowStockCount: low.n,
    expiredCount: expired.n,
    nearestBatches: nearest,
  };
}
