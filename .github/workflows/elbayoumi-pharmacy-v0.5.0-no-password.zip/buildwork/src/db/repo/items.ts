import { all, transaction, type Tx } from '../database';

export interface ItemRow {
  id: number;
  code: string;
  name: string;
  trade_name: string | null;
  category_id: number | null;
  category_name: string | null;
  manufacturer_id: number | null;
  manufacturer_name: string | null;
  unit: string;
  barcode: string | null;
  description: string | null;
  min_stock: number; // مضروب في 1000
  max_stock: number; // مضروب في 1000
  is_active: number;
  balance: number; // مضروب في 1000
  stock_value: number; // بالقرش
}

export interface ItemInput {
  id?: number;
  name: string;
  trade_name: string;
  category: string;
  manufacturer: string;
  unit: string;
  barcode: string;
  description: string;
  min_stock: number;
  max_stock: number;
}

const BASE_SQL = `
SELECT i.*, c.name AS category_name, m.name AS manufacturer_name,
  COALESCE(SUM(b.qty_remaining),0) AS balance,
  CAST(ROUND(COALESCE(SUM(b.qty_remaining * b.unit_cost),0) / 1000.0) AS INTEGER) AS stock_value
FROM items i
LEFT JOIN categories c ON c.id = i.category_id
LEFT JOIN manufacturers m ON m.id = i.manufacturer_id
LEFT JOIN batches b ON b.item_id = i.id
`;

export async function listItems(search: string, includeInactive: boolean): Promise<ItemRow[]> {
  const where: string[] = [];
  const params: string[] = [];
  if (!includeInactive) where.push('i.is_active = 1');
  const q = search.trim();
  if (q) {
    where.push('(i.name LIKE ? OR i.trade_name LIKE ? OR i.code LIKE ? OR i.barcode LIKE ?)');
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }
  const sql = `${BASE_SQL} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} GROUP BY i.id ORDER BY i.name`;
  return all<ItemRow>(sql, params);
}

export async function listLookup(table: 'categories' | 'manufacturers'): Promise<string[]> {
  const rows = await all<{ name: string }>(`SELECT name FROM ${table} ORDER BY name`);
  return rows.map((r) => r.name);
}

export function validateItem(input: ItemInput): string | null {
  if (!input.name.trim()) return 'اسم الصنف مطلوب';
  if (!input.unit.trim()) return 'وحدة القياس مطلوبة';
  if (!Number.isInteger(input.min_stock) || input.min_stock < 0) return 'الحد الأدنى غير صحيح (أرقام فقط، حتى 3 خانات عشرية)';
  if (!Number.isInteger(input.max_stock) || input.max_stock < 0) return 'الحد الأقصى غير صحيح (أرقام فقط، حتى 3 خانات عشرية)';
  if (input.max_stock > 0 && input.max_stock < input.min_stock) return 'الحد الأقصى يجب ألا يقل عن الحد الأدنى';
  return null;
}

async function ensureLookup(
  tx: Tx,
  table: 'categories' | 'manufacturers',
  name: string,
): Promise<number | null> {
  const n = name.trim();
  if (!n) return null;
  const found = await tx.all<{ id: number }>(`SELECT id FROM ${table} WHERE name = ?`, [n]);
  if (found.length) return found[0].id;
  return (await tx.run(`INSERT INTO ${table}(name) VALUES (?)`, [n])).lastId;
}

export async function saveItem(input: ItemInput): Promise<number> {
  const err = validateItem(input);
  if (err) throw new Error(err);
  const barcode = input.barcode.trim() || null;

  try {
    return await transaction(async (tx) => {
      const categoryId = await ensureLookup(tx, 'categories', input.category);
      const manufacturerId = await ensureLookup(tx, 'manufacturers', input.manufacturer);
      const fields = [
        input.name.trim(),
        input.trade_name.trim() || null,
        categoryId,
        manufacturerId,
        input.unit.trim(),
        barcode,
        input.description.trim() || null,
        input.min_stock,
        input.max_stock,
      ];

      if (input.id) {
        await tx.run(
          `UPDATE items SET name=?, trade_name=?, category_id=?, manufacturer_id=?, unit=?, barcode=?,
           description=?, min_stock=?, max_stock=?, updated_at=datetime('now','localtime') WHERE id=?`,
          [...fields, input.id],
        );
        await tx.run('INSERT INTO audit_log(entity,entity_id,action,details) VALUES (?,?,?,?)', [
          'item', input.id, 'update', JSON.stringify({ name: input.name.trim() }),
        ]);
        return input.id;
      }

      const next = await tx.all<{ n: number }>('SELECT COALESCE(MAX(id),0)+1 AS n FROM items');
      const code = `ITM-${String(next[0].n).padStart(5, '0')}`;
      const res = await tx.run(
        `INSERT INTO items(name,trade_name,category_id,manufacturer_id,unit,barcode,description,min_stock,max_stock,code)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [...fields, code],
      );
      await tx.run('INSERT INTO audit_log(entity,entity_id,action,details) VALUES (?,?,?,?)', [
        'item', res.lastId, 'create', JSON.stringify({ code, name: input.name.trim() }),
      ]);
      return res.lastId;
    });
  } catch (e) {
    const msg = String((e as Error).message ?? e);
    if (msg.includes('UNIQUE') && msg.includes('barcode')) throw new Error('هذا الباركود مسجل لصنف آخر');
    throw e;
  }
}

/** لا يوجد حذف للأصناف إطلاقاً؛ الإيقاف هو الوسيلة الوحيدة حتى لا تضيع أي حركة تاريخية. */
export async function setItemActive(id: number, active: boolean): Promise<void> {
  await transaction(async (tx) => {
    await tx.run("UPDATE items SET is_active=?, updated_at=datetime('now','localtime') WHERE id=?", [active ? 1 : 0, id]);
    await tx.run('INSERT INTO audit_log(entity,entity_id,action) VALUES (?,?,?)', [
      'item', id, active ? 'activate' : 'deactivate',
    ]);
  });
}
