import { CapacitorSQLite, SQLiteConnection, SQLiteDBConnection } from '@capacitor-community/sqlite';
import { MIGRATIONS } from './migrations';

const DB_NAME = 'elbayoumi_pharmacy';
const sqlite = new SQLiteConnection(CapacitorSQLite);
let conn: SQLiteDBConnection | null = null;

export type Param = string | number | null;

export interface Tx {
  all<T = Record<string, unknown>>(sql: string, params?: Param[]): Promise<T[]>;
  run(sql: string, params?: Param[]): Promise<{ changes: number; lastId: number }>;
}

export async function initDb(): Promise<void> {
  if (conn) return;
  const consistent = (await sqlite.checkConnectionsConsistency()).result;
  const exists = (await sqlite.isConnection(DB_NAME, false)).result;
  conn =
    consistent && exists
      ? await sqlite.retrieveConnection(DB_NAME, false)
      : await sqlite.createConnection(DB_NAME, false, 'no-encryption', 1, false);
  await conn.open();
  await conn.execute('PRAGMA foreign_keys = ON;', false);
  await migrate(conn);
}

async function migrate(db: SQLiteDBConnection): Promise<void> {
  await db.execute(
    'CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT (datetime(\'now\',\'localtime\')));',
  );
  const res = await db.query('SELECT COALESCE(MAX(version),0) AS v FROM schema_migrations');
  const current = Number(res.values?.[0]?.v ?? 0);
  for (const m of MIGRATIONS.filter((x) => x.version > current).sort((a, b) => a.version - b.version)) {
    // execute() يلفّ كل العبارات في معاملة واحدة، فإما تنجح الهجرة كاملة أو لا يحدث شيء.
    await db.execute(`${m.sql}\nINSERT INTO schema_migrations(version) VALUES (${m.version});`);
  }
}

function getDb(): SQLiteDBConnection {
  if (!conn) throw new Error('قاعدة البيانات لم تُفتح بعد');
  return conn;
}

export async function all<T = Record<string, unknown>>(sql: string, params: Param[] = []): Promise<T[]> {
  const res = await getDb().query(sql, params);
  return (res.values ?? []) as T[];
}

export async function run(sql: string, params: Param[] = []) {
  const res = await getDb().run(sql, params, true);
  return { changes: res.changes?.changes ?? 0, lastId: res.changes?.lastId ?? 0 };
}

/** كل عملية مالية أو مخزنية تمر من هنا: إما تُحفظ كاملة أو تُلغى كاملة. */
export async function transaction<T>(fn: (tx: Tx) => Promise<T>): Promise<T> {
  const db = getDb();
  await db.beginTransaction();
  try {
    const tx: Tx = {
      all: async <R,>(sql: string, params: Param[] = []) => ((await db.query(sql, params)).values ?? []) as R[],
      run: async (sql, params = []) => {
        const r = await db.run(sql, params, false);
        return { changes: r.changes?.changes ?? 0, lastId: r.changes?.lastId ?? 0 };
      },
    };
    const out = await fn(tx);
    await db.commitTransaction();
    return out;
  } catch (e) {
    if (await db.isTransactionActive()) await db.rollbackTransaction();
    throw e;
  }
}
