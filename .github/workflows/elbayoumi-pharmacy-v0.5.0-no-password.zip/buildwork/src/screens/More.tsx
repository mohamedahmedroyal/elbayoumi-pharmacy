const PHASES: { n: number; title: string; items: string; done: boolean }[] = [
  { n: 1, title: 'الأساس', items: 'الهوية، لوحة التحكم، الأصناف', done: true },
  { n: 2, title: 'الموردون والعملاء', items: 'إضافة الموردين والعملاء وعرض بياناتهم', done: true },
  { n: 3, title: 'الفواتير والمخزون', items: 'فواتير بيع وشراء متعددة الأصناف، تحديث الرصيد، الصرف حسب الأقرب انتهاءً FEFO', done: true },
  { n: 4, title: 'المالية الأساسية', items: 'الخزينة وسندات القبض والصرف والمصروفات', done: true },
  { n: 5, title: 'الأرباح والمخزون', items: 'حساب تكلفة البضاعة المباعة وصافي التشغيل والتنبيهات', done: true },
  { n: 6, title: 'التقارير والنسخ الاحتياطي', items: 'ملخص اليوم، تقرير فترة، تنبيهات المخزون والصلاحية، وتصدير JSON؛ الاستعادة وPDF لاحقاً', done: true },
  { n: 7, title: 'الاختبارات والتسليم', items: 'اختبارات شاملة، مراجعة المرتجعات والأرصدة، وبناء نسخة Release موقعة', done: false },
];

export default function More() {
  return (
    <>
      <header className="top">
        <h1>المزيد</h1>
        <p className="muted">النسخة 0.3.0 · إدارة الأطراف والمالية والتقارير</p>
      </header>
      <section className="block">
        <h2>مراحل البناء</h2>
        <ul className="rows">
          {PHASES.map((p) => (
            <li key={p.n}>
              <div>
                <b>{p.title}</b>
                <small>{p.items}</small>
              </div>
              <span className={p.done ? 'tag ok' : 'tag'}>{p.done ? 'مكتملة' : 'قادمة'}</span>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}
