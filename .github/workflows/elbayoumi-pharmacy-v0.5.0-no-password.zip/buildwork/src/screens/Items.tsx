import { useCallback, useEffect, useState } from 'react';
import { listItems, setItemActive, type ItemRow } from '../db/repo/items';
import { money } from '../lib/format';
import { qty } from '../lib/qty';
import ItemForm from './ItemForm';

export default function Items() {
  const [search, setSearch] = useState('');
  const [showInactive, setShowInactive] = useState(false);
  const [rows, setRows] = useState<ItemRow[] | null>(null);
  const [editing, setEditing] = useState<ItemRow | 'new' | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    listItems(search, showInactive).then(setRows).catch((e) => setError(String(e?.message ?? e)));
  }, [search, showInactive]);

  useEffect(() => {
    const t = setTimeout(load, 150);
    return () => clearTimeout(t);
  }, [load]);

  async function toggle(item: ItemRow) {
    const next = !item.is_active;
    if (!next && !window.confirm(`إيقاف الصنف "${item.name}"؟ لن يظهر في الفواتير الجديدة وستبقى حركاته محفوظة.`)) return;
    try {
      await setItemActive(item.id, next);
      load();
    } catch (e) {
      setError(String((e as Error).message ?? e));
    }
  }

  return (
    <>
      <header className="top">
        <h1>الأصناف</h1>
      </header>

      <div className="searchbar">
        <input
          type="search"
          placeholder="ابحث بالاسم أو الكود أو الباركود"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <label className="check">
          <input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} />
          إظهار الأصناف الموقوفة
        </label>
      </div>

      {error && <p className="error">{error}</p>}

      {rows && rows.length === 0 && (
        <p className="empty">
          {search ? 'لا توجد نتائج مطابقة للبحث.' : 'لم تُضف أي أصناف بعد. اضغط زر الإضافة لتسجيل أول صنف.'}
        </p>
      )}

      <ul className="cards">
        {rows?.map((it) => (
          <li key={it.id} className={it.is_active ? '' : 'off'}>
            <div className="card-head">
              <div>
                <b>{it.name}</b>
                <small>
                  {it.code}
                  {it.category_name ? ` · ${it.category_name}` : ''}
                </small>
              </div>
              {!it.is_active && <span className="tag">موقوف</span>}
            </div>
            <div className="card-grid">
              <span>الرصيد <b>{qty(it.balance)} {it.unit}</b></span>
              <span>قيمة المخزون <b>{money(it.stock_value)}</b></span>
              {it.min_stock > 0 && it.balance <= it.min_stock && it.is_active ? (
                <span className="tag warn">وصل للحد الأدنى</span>
              ) : null}
            </div>
            <div className="card-actions">
              <button className="ghost" onClick={() => setEditing(it)}>تعديل</button>
              <button className="ghost" onClick={() => toggle(it)}>{it.is_active ? 'إيقاف' : 'تفعيل'}</button>
            </div>
          </li>
        ))}
      </ul>

      <button className="fab" aria-label="إضافة صنف" onClick={() => setEditing('new')}>+</button>

      {editing && (
        <ItemForm
          item={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            load();
          }}
        />
      )}
    </>
  );
}
