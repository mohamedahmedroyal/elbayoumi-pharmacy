import { useEffect, useState } from 'react';
import { loadDashboard, type DashboardData } from '../db/repo/dashboard';
import { daysLabel, money, num } from '../lib/format';
import { qty } from '../lib/qty';

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadDashboard().then(setData).catch((e) => setError(String(e?.message ?? e)));
  }, []);

  if (error) return <p className="error">{error}</p>;
  if (!data) return <p className="muted pad">جارٍ التحميل…</p>;

  return (
    <>
      <header className="top">
        <h1>البيومي فارمسي</h1>
        <p className="muted">صيدلية بيطرية</p>
      </header>

      <section className="hero">
        <p>قيمة المخزون بالتكلفة</p>
        <strong>{money(data.stockValue)}</strong>
        <div className="hero-row">
          <span>{num(data.itemCount)} صنف نشط</span>
        </div>
      </section>

      <section className="stats">
        <div className={`stat ${data.lowStockCount ? 'warn' : ''}`}>
          <b>{num(data.lowStockCount)}</b>
          <span>أصناف وصلت للحد الأدنى</span>
        </div>
        <div className={`stat ${data.expiredCount ? 'bad' : ''}`}>
          <b>{num(data.expiredCount)}</b>
          <span>تشغيلات منتهية بها رصيد</span>
        </div>
      </section>

      <section className="block">
        <h2>أقرب التشغيلات انتهاءً</h2>
        {data.nearestBatches.length === 0 ? (
          <p className="empty">لا توجد تشغيلات بعد. ستظهر هنا بعد تسجيل أول فاتورة شراء.</p>
        ) : (
          <ul className="rows">
            {data.nearestBatches.map((b) => (
              <li key={b.id}>
                <div>
                  <b>{b.item_name}</b>
                  <small>تشغيلة {b.batch_no} · الكمية {qty(b.qty_remaining)}</small>
                </div>
                <span className={b.days_left < 0 ? 'tag bad' : b.days_left < 90 ? 'tag warn' : 'tag'}>
                  {daysLabel(b.days_left)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
