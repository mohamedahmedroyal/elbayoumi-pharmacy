import { useCallback, useEffect, useState } from 'react';
import { all } from '../db/database';
import { money } from '../lib/format';

type Summary = { sales:number; cogs:number; expenses:number; purchases:number; sales_count:number; purchase_count:number };
type StockAlert = { id:number; name:string; code:string; balance:number; min_stock:number; unit:string };
type ExpiryAlert = { id:number; name:string; batch_no:string; expiry_date:string; qty_remaining:number; unit:string };
const today = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
export default function ProfitReports(){
 const [from,setFrom]=useState(today()); const [to,setTo]=useState(today());
 const [summary,setSummary]=useState<Summary|null>(null); const [stock,setStock]=useState<StockAlert[]>([]); const [expiry,setExpiry]=useState<ExpiryAlert[]>([]); const [error,setError]=useState('');
 const load=useCallback(async()=>{
  setError('');
  if(from>to){setError('تاريخ البداية يجب أن يسبق تاريخ النهاية');return;}
  const [s,st,ex]=await Promise.all([
   all<Summary>(`SELECT
    COALESCE((SELECT SUM(total) FROM sales_invoices WHERE date(created_at)>=date(?) AND date(created_at)<=date(?)),0) sales,
    COALESCE((SELECT SUM(ROUND(ABS(sm.qty)*sm.unit_cost/1000.0)) FROM stock_movements sm WHERE sm.movement_type='sale' AND sm.doc_type='sale' AND date(sm.created_at)>=date(?) AND date(sm.created_at)<=date(?)),0) cogs,
    COALESCE((SELECT SUM(amount) FROM expenses WHERE date(created_at)>=date(?) AND date(created_at)<=date(?)),0) expenses,
    COALESCE((SELECT SUM(total) FROM purchase_invoices WHERE date(created_at)>=date(?) AND date(created_at)<=date(?)),0) purchases,
    (SELECT COUNT(*) FROM sales_invoices WHERE date(created_at)>=date(?) AND date(created_at)<=date(?)) sales_count,
    (SELECT COUNT(*) FROM purchase_invoices WHERE date(created_at)>=date(?) AND date(created_at)<=date(?)) purchase_count`,[from,to,from,to,from,to,from,to,from,to,from,to]),
   all<StockAlert>(`SELECT i.id,i.name,i.code,i.unit,i.min_stock,COALESCE(SUM(b.qty_remaining),0) balance FROM items i LEFT JOIN batches b ON b.item_id=i.id WHERE i.is_active=1 GROUP BY i.id HAVING COALESCE(SUM(b.qty_remaining),0)<=i.min_stock ORDER BY balance,i.name`),
   all<ExpiryAlert>(`SELECT b.id,i.name,b.batch_no,b.expiry_date,b.qty_remaining,i.unit FROM batches b JOIN items i ON i.id=b.item_id WHERE b.qty_remaining>0 AND b.expiry_date<=date('now','localtime','+180 day') ORDER BY b.expiry_date LIMIT 100`)
  ]);
  setSummary(s[0]??null);setStock(st);setExpiry(ex);
 },[from,to]);
 useEffect(()=>{load().catch(e=>setError(String(e?.message??e)));},[load]);
 const gross=summary?summary.sales-summary.cogs:0; const net=summary?gross-summary.expenses:0;
 return <section className="block" style={{marginTop:14}}>
  <h2>الأرباح والمخزون</h2>
  <p className="muted">حساب تقديري للفترة المختارة اعتماداً على تكلفة التشغيلات المسجلة وحركات البيع. لا يشمل الضرائب أو التسويات غير المسجلة.</p>
  <div className="two"><label className="muted">من<input type="date" value={from} onChange={e=>setFrom(e.target.value)}/></label><label className="muted">إلى<input type="date" value={to} onChange={e=>setTo(e.target.value)}/></label></div>
  <button className="primary" style={{marginTop:10}} onClick={()=>load().catch(e=>setError(String(e)))}>تحديث الحساب</button>
  {error&&<p className="error">{error}</p>}
  {summary&&<><ul className="rows" style={{marginTop:12}}>
   <li><span>المبيعات ({summary.sales_count} فاتورة)</span><b>{money(summary.sales)}</b></li>
   <li><span>تكلفة البضاعة المباعة</span><b>{money(summary.cogs)}</b></li>
   <li><span>مجمل الربح</span><b>{money(gross)}</b></li>
   <li><span>المصروفات</span><b>{money(summary.expenses)}</b></li>
   <li><span>صافي تشغيلي تقديري</span><b>{money(net)}</b></li>
   <li><span>المشتريات ({summary.purchase_count} فاتورة)</span><b>{money(summary.purchases)}</b></li>
  </ul></>}
  <h2 style={{marginTop:20}}>أصناف وصلت للحد الأدنى</h2>
  {stock.length===0?<p className="empty">لا توجد أصناف تحت حد الطلب حالياً.</p>:<ul className="rows">{stock.map(x=><li key={x.id}><div><b>{x.name}</b><small>{x.code} · الحد الأدنى {x.min_stock/1000} {x.unit}</small></div><span className="tag">المتاح {x.balance/1000}</span></li>)}</ul>}
  <h2 style={{marginTop:20}}>تشغيلات قريبة من الانتهاء (180 يوم)</h2>
  {expiry.length===0?<p className="empty">لا توجد تشغيلات قريبة من الانتهاء.</p>:<ul className="rows">{expiry.map(x=><li key={x.id}><div><b>{x.name}</b><small>تشغيلة {x.batch_no} · صلاحية {x.expiry_date}</small></div><span className="tag">{x.qty_remaining/1000} {x.unit}</span></li>)}</ul>}
 </section>;
}
