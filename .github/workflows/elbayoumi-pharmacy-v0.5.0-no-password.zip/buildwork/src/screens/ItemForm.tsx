import { useEffect, useState } from 'react';
import { parseQty, qtyInput } from '../lib/qty';
import { listLookup, saveItem, validateItem, type ItemInput, type ItemRow } from '../db/repo/items';

interface Props {
  item: ItemRow | null;
  onClose: () => void;
  onSaved: () => void;
}

export default function ItemForm({ item, onClose, onSaved }: Props) {
  const [f, setF] = useState({
    name: item?.name ?? '',
    trade_name: item?.trade_name ?? '',
    category: item?.category_name ?? '',
    manufacturer: item?.manufacturer_name ?? '',
    unit: item?.unit ?? 'علبة',
    barcode: item?.barcode ?? '',
    description: item?.description ?? '',
    min_stock: qtyInput(item?.min_stock ?? 0),
    max_stock: qtyInput(item?.max_stock ?? 0),
  });
  const [categories, setCategories] = useState<string[]>([]);
  const [manufacturers, setManufacturers] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    listLookup('categories').then(setCategories).catch(() => undefined);
    listLookup('manufacturers').then(setManufacturers).catch(() => undefined);
  }, []);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setF({ ...f, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const min = parseQty(f.min_stock);
    const max = parseQty(f.max_stock);
    if (min === null || max === null) return setError('الحد الأدنى والأقصى: أرقام فقط، حتى 3 خانات عشرية (مثال 0.5)');
    const input: ItemInput = { id: item?.id, ...f, min_stock: min, max_stock: max };
    const problem = validateItem(input);
    if (problem) return setError(problem);
    setSaving(true);
    try {
      await saveItem(input);
      onSaved();
    } catch (err) {
      setError(String((err as Error).message ?? err));
      setSaving(false);
    }
  }

  return (
    <div className="sheet-back">
      <form className="sheet" onSubmit={submit}>
        <div className="sheet-head">
          <h2>{item ? 'تعديل صنف' : 'صنف جديد'}</h2>
          <button type="button" className="ghost" onClick={onClose}>إلغاء</button>
        </div>

        <label>اسم الصنف<input value={f.name} onChange={set('name')} autoFocus /></label>
        <label>الاسم التجاري<input value={f.trade_name} onChange={set('trade_name')} /></label>
        <div className="two">
          <label>التصنيف<input list="cats" value={f.category} onChange={set('category')} /></label>
          <label>الشركة المنتجة<input list="mfrs" value={f.manufacturer} onChange={set('manufacturer')} /></label>
        </div>
        <datalist id="cats">{categories.map((c) => <option key={c} value={c} />)}</datalist>
        <datalist id="mfrs">{manufacturers.map((c) => <option key={c} value={c} />)}</datalist>
        <div className="two">
          <label>وحدة القياس<input value={f.unit} onChange={set('unit')} /></label>
          <label>الباركود<input inputMode="numeric" value={f.barcode} onChange={set('barcode')} /></label>
        </div>
        <div className="two">
          <label>الحد الأدنى للمخزون<input inputMode="decimal" value={f.min_stock} onChange={set('min_stock')} /></label>
          <label>الحد الأقصى للمخزون<input inputMode="decimal" value={f.max_stock} onChange={set('max_stock')} /></label>
        </div>
        <label>وصف الصنف<textarea rows={2} value={f.description} onChange={set('description')} /></label>

        {error && <p className="error">{error}</p>}
        <button className="primary" disabled={saving}>{saving ? 'جارٍ الحفظ…' : 'حفظ الصنف'}</button>
      </form>
    </div>
  );
}
