import { useCallback, useEffect, useMemo, useState, type CSSProperties } from 'react';
import { invoiceItems, recentInvoices, saveInvoice, type InvoiceItem, type InvoiceKind, type InvoiceLine, type InvoiceSummary } from '../db/repo/invoices';
import { money } from '../lib/format';
import { parseQty, qty } from '../lib/qty';

function moneyInput(value: string): number | null {
  const normalized=value.trim().replace(/[٠-٩]/g,d=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).replace(/[٫,]/g,'.');
  if (!/^\d+(\.\d{1,2})?$/.test(normalized)) return null;
  const [a,b='']=normalized.split('.'); return Number(a)*100+Number(b.padEnd(2,'0'));
}
export default function Invoices() {
  const [kind,setKind]=useState<InvoiceKind>('sale');
  const [items,setItems]=useState<InvoiceItem[]>([]);
  const [history,setHistory]=useState<InvoiceSummary[]>([]);
  const [itemId,setItemId]=useState('');
  const [quantity,setQuantity]=useState('1');
  const [price,setPrice]=useState('');
  const [cost,setCost]=useState('');
  const [batchNo,setBatchNo]=useState('');
  const [expiry,setExpiry]=useState('');
  const [party,setParty]=useState('');
  const [notes,setNotes]=useState('');
  const [lines,setLines]=useState<InvoiceLine[]>([]);
  const [error,setError]=useState('');
  const [saving,setSaving]=useState(false);
  const load=useCallback(async()=>{const [a,b]=await Promise.all([invoiceItems(),recentInvoices(kind)]);setItems(a);setHistory(b);},[kind]);
  useEffect(()=>{load().catch(e=>setError(String(e)));},[load]);
  const selected=items.find(i=>String(i.id)===itemId);
  const total=useMemo(()=>lines.reduce((s,l)=>s+Math.round(l.qty*(kind==='purchase'?(l.cost??0):l.price)/1000),0),[lines,kind]);
  function addLine(){
    setError('');
    if(!selected){setError('اختر الصنف أولاً');return;}
    const q=parseQty(quantity),p=moneyInput(price),c=moneyInput(cost);
    if(q===null||q<=0){setError('اكتب كمية صحيحة');return;}
    if(p===null){setError('اكتب سعر بيع صحيح بالجنيه');return;}
    if(kind==='purchase'&&c===null){setError('اكتب تكلفة شراء صحيحة بالجنيه');return;}
    if(kind==='sale'&&selected.balance<q){setError(`الرصيد المتاح ${qty(selected.balance)} ${selected.unit}`);return;}
    const old=lines.find(l=>l.item_id===selected.id);
    if(old){setLines(lines.map(l=>l.item_id===selected.id?{...l,qty:l.qty+q,price:p,cost:c??undefined}:l));}
    else setLines([...lines,{item_id:selected.id,name:selected.name,unit:selected.unit,qty:q,price:p,cost:c??undefined}]);
    setQuantity('1');setPrice('');setCost('');
  }
  async function submit(){
    setError('');setSaving(true);
    try{await saveInvoice(kind,lines,{party,batchNo,expiry,notes});setLines([]);setParty('');setNotes('');setBatchNo('');setExpiry('');await load();}
    catch(e){setError(String((e as Error).message??e));}
    finally{setSaving(false);}
  }
  return <>
    <header className="top"><h1>الفواتير</h1><p className="muted">تسجيل المشتريات والمبيعات وحركة المخزون</p></header>
    <div className="two"><button className={kind==='sale'?'primary':'ghost'} onClick={()=>{setKind('sale');setLines([]);setError('');}}>فاتورة بيع</button><button className={kind==='purchase'?'primary':'ghost'} onClick={()=>{setKind('purchase');setLines([]);setError('');}}>فاتورة شراء</button></div>
    <section className="block" style={{marginTop:14}}><h2>{kind==='sale'?'بيانات البيع':'بيانات الشراء'}</h2>
      <div className="searchbar"><label className="muted">{kind==='sale'?'اسم العميل (اختياري)':'اسم المورد (اختياري)'}<input value={party} onChange={e=>setParty(e.target.value)} placeholder="الاسم" /></label></div>
      {kind==='purchase'&&<div className="two"><label className="muted">رقم التشغيلة<input value={batchNo} onChange={e=>setBatchNo(e.target.value)} placeholder="BATCH-01" /></label><label className="muted">تاريخ الصلاحية<input type="date" value={expiry} onChange={e=>setExpiry(e.target.value)} /></label></div>}
    </section>
    <section className="block"><h2>إضافة صنف للفاتورة</h2>
      <label className="muted">الصنف<select value={itemId} onChange={e=>setItemId(e.target.value)} style={fieldStyle}><option value="">اختر الصنف</option>{items.map(i=><option key={i.id} value={i.id}>{i.name} — رصيد {qty(i.balance)}</option>)}</select></label>
      <div className="two"><label className="muted">الكمية<input inputMode="decimal" value={quantity} onChange={e=>setQuantity(e.target.value)} /></label><label className="muted">سعر البيع للوحدة (جنيه)<input inputMode="decimal" value={price} onChange={e=>setPrice(e.target.value)} placeholder="0.00" /></label></div>
      {kind==='purchase'&&<label className="muted">تكلفة الشراء للوحدة (جنيه)<input inputMode="decimal" value={cost} onChange={e=>setCost(e.target.value)} placeholder="0.00" /></label>}
      <button className="primary" onClick={addLine}>إضافة إلى الفاتورة</button>
    </section>
    {lines.length>0&&<section className="block"><h2>أصناف الفاتورة</h2><ul className="rows">{lines.map(l=><li key={l.item_id}><div><b>{l.name}</b><small>{qty(l.qty)} {l.unit} × {money(kind==='purchase'?(l.cost??0):l.price)}</small></div><div style={{textAlign:'end'}}><b>{money(Math.round(l.qty*(kind==='purchase'?(l.cost??0):l.price)/1000))}</b><button className="ghost" onClick={()=>setLines(lines.filter(x=>x.item_id!==l.item_id))}>حذف</button></div></li>)}</ul><div className="hero" style={{marginTop:12}}><p>إجمالي الفاتورة</p><strong>{money(total)}</strong></div><label className="muted">ملاحظات<textarea value={notes} onChange={e=>setNotes(e.target.value)} style={fieldStyle}/></label><button className="primary" disabled={saving} onClick={submit}>{saving?'جارٍ الحفظ…':'حفظ الفاتورة وتحديث المخزون'}</button></section>}
    {error&&<p className="error">{error}</p>}
    <section className="block"><h2>آخر {kind==='sale'?'فواتير البيع':'فواتير الشراء'}</h2>{history.length===0?<p className="empty">لا توجد فواتير مسجلة حتى الآن.</p>:<ul className="rows">{history.map(h=><li key={h.id}><div><b>{h.invoice_no}</b><small>{h.party_name||'بدون اسم'} · {h.created_at}</small></div><b>{money(h.total)}</b></li>)}</ul>}</section>
  </>;
}
const fieldStyle: CSSProperties={width:'100%',padding:'11px 12px',border:'1px solid var(--line)',borderRadius:10,background:'var(--card)',color:'var(--ink)',marginTop:4,font:'inherit'};
