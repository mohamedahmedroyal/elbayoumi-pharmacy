/** القرش -> نص بالجنيه. مثال: 12550 -> "125.50 ج.م" */
export function money(piasters: number): string {
  const v = piasters / 100;
  return `${v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ج.م`;
}

export function num(n: number): string {
  return n.toLocaleString('en-US');
}

export function daysLabel(days: number): string {
  if (days < 0) return `منتهية منذ ${num(-days)} يوم`;
  if (days === 0) return 'تنتهي اليوم';
  return `متبقي ${num(days)} يوم`;
}
