// الكميات تُخزَّن كأعداد صحيحة بالألف (1 علبة = 1000، نصف علبة = 500) لدعم الكسور حتى 3 خانات بدون أخطاء عشرية.
export const QTY_SCALE = 1000;

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';

/** نص مكتوب بواسطة المستخدم -> كمية مخزنة. يرجع null لو الصيغة غير صحيحة. */
export function parseQty(text: string): number | null {
  let t = text.trim().replace(/[٠-٩]/g, (d) => String(AR_DIGITS.indexOf(d))).replace(/[٫,]/g, '.');
  if (t === '') return 0;
  if (!/^\d+(\.\d{1,3})?$/.test(t)) return null;
  const [whole, frac = ''] = t.split('.');
  return Number(whole) * QTY_SCALE + Number(frac.padEnd(3, '0'));
}

/** كمية مخزنة -> نص للعرض (بدون أصفار زائدة). */
export function qty(stored: number): string {
  const sign = stored < 0 ? '-' : '';
  const abs = Math.abs(stored);
  const whole = Math.floor(abs / QTY_SCALE);
  const frac = String(abs % QTY_SCALE).padStart(3, '0').replace(/0+$/, '');
  return `${sign}${whole.toLocaleString('en-US')}${frac ? '.' + frac : ''}`;
}

/** كمية مخزنة -> نص لحقل الإدخال. */
export function qtyInput(stored: number): string {
  return qty(stored).replace(/,/g, '');
}
