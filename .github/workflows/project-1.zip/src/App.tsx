import { useEffect, useState } from 'react';
import { initDb } from './db/database';
import Dashboard from './screens/Dashboard';
import Items from './screens/Items';
import More from './screens/More';

type Tab = 'home' | 'items' | 'more';

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: 'home', label: 'الرئيسية', icon: 'M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z' },
  { id: 'items', label: 'الأصناف', icon: 'M4 7l8-4 8 4v10l-8 4-8-4zM4 7l8 4 8-4M12 11v10' },
  { id: 'more', label: 'المزيد', icon: 'M5 12h.01M12 12h.01M19 12h.01' },
];

export default function App() {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('home');

  useEffect(() => {
    initDb()
      .then(() => setReady(true))
      .catch((e) => setError(String(e?.message ?? e)));
  }, []);

  if (error) {
    return (
      <div className="boot">
        <h1>تعذّر فتح قاعدة البيانات</h1>
        <p>{error}</p>
        <p className="muted">أغلق التطبيق وافتحه من جديد. لو تكرر الخطأ ابعت لي هذا النص.</p>
      </div>
    );
  }
  if (!ready) return <div className="boot"><p>جارٍ التحميل…</p></div>;

  return (
    <div className="app">
      <main className="screen">
        {tab === 'home' && <Dashboard />}
        {tab === 'items' && <Items />}
        {tab === 'more' && <More />}
      </main>
      <nav className="tabbar" aria-label="التنقل الرئيسي">
        {TABS.map((t) => (
          <button key={t.id} className={tab === t.id ? 'on' : ''} onClick={() => setTab(t.id)}>
            <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d={t.icon} />
            </svg>
            <span>{t.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}
