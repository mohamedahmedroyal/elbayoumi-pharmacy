const PHASES: { n: number; title: string; items: string; done: boolean }[] = [
  { n: 1, title: 'الأساس', items: 'الهوية، لوحة التحكم، الأصناف', done: true },
  { n: 2, title: 'الموردون والعملاء والتشغيلات', items: 'التشغيلات، الصلاحيات، سجل حركة الصنف', done: false },
  { n: 3, title: 'الفواتير والمرتجعات', items: 'شراء، بيع، مرتجعات، FEFO', done: false },
  { n: 4, title: 'المالية', items: 'الخزينة، البنوك، السندات، المصروفات', done: false },
  { n: 5, title: 'الأرباح', items: 'محرك الأرباح، المركز المالي', done: false },
  { n: 6, title: 'التقارير والنسخ الاحتياطي', items: 'PDF، الباركود، النسخ الاحتياطي، الإعدادات', done: false },
  { n: 7, title: 'الاختبارات والتسليم', items: 'اختبارات شاملة وبناء النسخة النهائية', done: false },
];

export default function More() {
  return (
    <>
      <header className="top">
        <h1>المزيد</h1>
        <p className="muted">النسخة 0.1.0 · المرحلة الأولى</p>
      </header>
      <section className="block">
        <h2>مراحل البناء</h2>
        <ul className="rows">
          {PHASES.map((p) => (
            <li key={p.n}>
              <div>
                <b>{p.title}</b>
                <small>{p.items}</small>
              </div>
              <span className={p.done ? 'tag ok' : 'tag'}>{p.done ? 'مكتملة' : 'قادمة'}</span>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}
