// كل المبالغ تُخزَّن كأعداد صحيحة بالقرش (1 جنيه = 100 قرش) لتفادي أخطاء الكسور العشرية.
// الكميات أعداد صحيحة مضروبة في 1000 (نصف علبة = 500) لدعم الكسور بدقة. unit_cost = تكلفة الوحدة الكاملة بالقرش.

export interface Migration {
  version: number;
  sql: string;
}

export const MIGRATIONS: Migration[] = [
  {
    version: 1,
    sql: `
CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);

CREATE TABLE manufacturers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);

CREATE TABLE suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  notes TEXT,
  opening_balance INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  notes TEXT,
  opening_balance INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  trade_name TEXT,
  category_id INTEGER REFERENCES categories(id),
  manufacturer_id INTEGER REFERENCES manufacturers(id),
  unit TEXT NOT NULL DEFAULT 'علبة',
  barcode TEXT,
  description TEXT,
  min_stock INTEGER NOT NULL DEFAULT 0 CHECK (min_stock >= 0),
  max_stock INTEGER NOT NULL DEFAULT 0 CHECK (max_stock >= 0),
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_items_barcode ON items(barcode) WHERE barcode IS NOT NULL;
CREATE INDEX ix_items_name ON items(name);

CREATE TABLE batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES items(id),
  supplier_id INTEGER REFERENCES suppliers(id),
  batch_no TEXT NOT NULL,
  purchase_date TEXT NOT NULL,
  production_date TEXT,
  expiry_date TEXT NOT NULL,
  qty_in INTEGER NOT NULL CHECK (qty_in >= 0),
  qty_sold INTEGER NOT NULL DEFAULT 0 CHECK (qty_sold >= 0),
  qty_sales_returned INTEGER NOT NULL DEFAULT 0 CHECK (qty_sales_returned >= 0),
  qty_purchase_returned INTEGER NOT NULL DEFAULT 0 CHECK (qty_purchase_returned >= 0),
  qty_remaining INTEGER NOT NULL CHECK (qty_remaining >= 0),
  unit_price INTEGER NOT NULL DEFAULT 0,
  unit_cost INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_batches_item ON batches(item_id);
CREATE INDEX ix_batches_expiry ON batches(expiry_date);

CREATE TABLE stock_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES items(id),
  batch_id INTEGER REFERENCES batches(id),
  movement_type TEXT NOT NULL,
  qty INTEGER NOT NULL,
  unit_cost INTEGER NOT NULL DEFAULT 0,
  doc_type TEXT,
  doc_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_movements_item ON stock_movements(item_id, created_at);

CREATE TABLE audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity TEXT NOT NULL,
  entity_id INTEGER,
  action TEXT NOT NULL,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

INSERT INTO settings(key,value) VALUES
  ('pharmacy_name','البيومي فارمسي'),
  ('currency','EGP'),
  ('vat_enabled','0'),
  ('vat_rate','14'),
  ('expiry_warning_days','180');
`,
  },
];
